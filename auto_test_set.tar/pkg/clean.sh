#!/bin/bash

rm -rf make_video_sln.sh
rm -rf make_audio_sln.sh
rm -rf make_image_sln.sh
rm -rf ffmpeg_video.sh
rm -rf ffmpeg_audio.sh
rm -rf ffmpeg_image.sh
